# PhotoCloud — Android Release Build (1.1.0)

Package Name: `com.valerio.photocloud`
Version: `1.1.0` (versionCode `2`)
Target SDK: Android 35 (Min SDK 26)
Server Endpoint: `http://localhost:3000`

## Comandi per compilare l'APK / AAB firmato in locale
```bash
./gradlew assembleRelease
./gradlew bundleRelease
```
