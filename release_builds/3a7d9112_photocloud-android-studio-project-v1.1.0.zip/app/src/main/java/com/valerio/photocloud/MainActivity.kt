package com.valerio.photocloud

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * PhotoCloud - Native Android Client + Hybrid Encrypted Vault
 * Version: 1.1.0 (Code 2)
 * Endpoint: http://localhost:3000
 */
class MainActivity : ComponentActivity() {
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var webViewRef by remember { mutableStateOf<WebView?>(null) }
                var currentTab by remember { mutableStateOf("gallery") }

                val filePicker = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.GetMultipleContents()
                ) { uris ->
                    filePathCallback?.onReceiveValue(uris.toTypedArray())
                    filePathCallback = null
                }

                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = currentTab == "gallery",
                                onClick = {
                                    currentTab = "gallery"
                                    webViewRef?.loadUrl("http://localhost:3000/")
                                },
                                icon = { Icon(Icons.Default.PhotoLibrary, contentDescription = "Galleria") },
                                label = { Text("Galleria") }
                            )
                            NavigationBarItem(
                                selected = currentTab == "trash",
                                onClick = {
                                    currentTab = "trash"
                                    webViewRef?.loadUrl("http://localhost:3000/trash")
                                },
                                icon = { Icon(Icons.Default.DeleteOutline, contentDescription = "Cestino") },
                                label = { Text("Cestino") }
                            )
                            NavigationBarItem(
                                selected = currentTab == "security",
                                onClick = {
                                    currentTab = "security"
                                    webViewRef?.loadUrl("http://localhost:3000/security")
                                },
                                icon = { Icon(Icons.Default.Security, contentDescription = "Sicurezza") },
                                label = { Text("Sicurezza") }
                            )
                        }
                    }
                ) { innerPadding ->
                    AndroidView(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                        factory = { context ->
                            WebView(context).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.allowFileAccess = true
                                settings.cacheMode = WebSettings.LOAD_DEFAULT
                                webViewClient = WebViewClient()
                                webChromeClient = object : WebChromeClient() {
                                    override fun onShowFileChooser(
                                        webView: WebView?,
                                        callback: ValueCallback<Array<Uri>>?,
                                        params: FileChooserParams?
                                    ): Boolean {
                                        filePathCallback?.onReceiveValue(null)
                                        filePathCallback = callback
                                        filePicker.launch("*/*")
                                        return true
                                    }
                                }
                                loadUrl("http://localhost:3000")
                                webViewRef = this
                            }
                        }
                    )
                }

                BackHandler(enabled = webViewRef?.canGoBack() == true) {
                    webViewRef?.goBack()
                }
            }
        }
    }

    companion object {
        /**
         * Native Kotlin implementation of PhotoCloud AES-256-CFB + PBKDF2-HMAC-SHA256
         * matching main.py decrypt_file(encrypted_data, key).
         */
        fun decryptMedia(encryptedData: ByteArray, apiKey: String): ByteArray {
            val salt = encryptedData.copyOfRange(0, 16)
            val iv = encryptedData.copyOfRange(16, 32)
            val ciphertext = encryptedData.copyOfRange(32, encryptedData.size)

            val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val spec = PBEKeySpec(apiKey.toCharArray(), salt, 100000, 256)
            val secretKey = SecretKeySpec(factory.generateSecret(spec).encoded, "AES")

            val cipher = Cipher.getInstance("AES/CFB/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey, IvParameterSpec(iv))
            return cipher.doFinal(ciphertext)
        }
    }
}
